# sample C++ library

Example based on https://github.com/springmeyer/hello-gyp
