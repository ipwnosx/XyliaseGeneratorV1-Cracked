# Test app

Demonstrates an example Node.js C++ app that depends on an external static library.

Because the external `mylib.a` library is statically built and linked it will be available inside the `app3.node` binary. See the `app4` example for how to handle shared libraries.
