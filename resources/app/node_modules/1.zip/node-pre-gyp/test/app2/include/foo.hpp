#ifndef FOO_HPP
#define FOO_HPP

#define HELLO_WORLD "hello"

#endif
