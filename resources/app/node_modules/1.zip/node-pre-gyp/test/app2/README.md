# Test app

Demonstrates a very custom situation where an option must be passed to node-gyp in order for the binding.gyp to be properly configured.
