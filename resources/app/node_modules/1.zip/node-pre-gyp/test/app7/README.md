# Test app

Demonstrates using N-API to return a JavaScript string object.
