# Test app

Demonstrates a simple configuration that uses node-pre-gyp.
