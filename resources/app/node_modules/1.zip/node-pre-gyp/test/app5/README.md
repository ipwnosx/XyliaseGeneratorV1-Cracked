# Test app

Tests installing a module that depends on node-pre-gyp (arbitrarily) and depends on a module that needs node-pre-gyp at build time.

This is to test https://github.com/mapbox/node-pre-gyp/issues/61.