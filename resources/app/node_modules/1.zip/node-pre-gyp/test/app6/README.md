# Test app

Tests installing a module that depends on two modules that use node-pre-gyp at build time.
