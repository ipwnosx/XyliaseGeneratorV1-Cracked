# Test app

Demonstrates a simpler configuration that uses node-pre-gyp.
