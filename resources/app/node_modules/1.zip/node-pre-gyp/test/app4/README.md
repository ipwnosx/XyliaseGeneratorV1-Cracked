# Test app

Demonstrates an example Node.js C++ app that depends on an external shared library.

See the `app3` example for how to handle static libraries.

See https://code.google.com/p/gyp/issues/detail?id=315 for gory details about rpath decisions/defaults for gyp on linux.
